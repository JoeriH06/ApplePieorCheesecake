<?php $__env->startSection('title', 'Apple or Cheesecake'); ?>

<?php $__env->startSection('content'); ?>
<section class="p-4">
    <section class="text-center">
        <h1 class="text-lg sm:text-xl">Today is <?php echo e($dayType); ?> day!!</h1>
        <img src="<?php echo e(asset($dayType === 'Apple Pie' ? '/images/applepie.jpg' : '/images/cheesecake.jpg')); ?>"
            alt="<?php echo e($dayType); ?>" class="sm:w-1/3 mx-auto mt-4 mb-4 border-4 border-indigo-300">

        <section class="text-lg sm:text-xl">
            <p class="font-bold">Times to bake an apple pie cheap:</p>
            <?php if(count($optimalTimes) > 0): ?>
                <?php for($i = 0; $i < min(count($optimalTimes), 2); $i++): ?>
                    <p><?php echo e($optimalTimes[$i]); ?></p>
                <?php endfor; ?>
            <?php else: ?>
                <p>There are no optimal times to bake an apple pie today</p>
            <?php endif; ?>

            <p class="font-bold">Some other times you can bake an apple pie less cheap:</p>
            <?php if(count($limitedTimes) > 0): ?>
                <?php for($i = 0; $i < min(count($limitedTimes), 2); $i++): ?>
                    <p><?php echo e($limitedTimes[$i]); ?></p>
                <?php endfor; ?>
            <?php else: ?>
                <p>There are no limited times to bake an apple pie today</p>
            <?php endif; ?>

            <p class="font-bold">Advise to make a cheesecake at these times:</p>
            <?php if(count($worstTimes) > 0): ?>
                <?php for($i = 0; $i < min(count($worstTimes), 2); $i++): ?>
                    <p><?php echo e($worstTimes[$i]); ?></p>
                <?php endfor; ?>
            <?php else: ?>
                <p>There are no bad times to bake an apple pie today</p>
            <?php endif; ?>
        </section>

        <section>
            <p class="sm:text-lg">
                Click <a href="<?php echo e(route('detailedpage')); ?>" class="text-blue-500 hover:text-blue-700">HERE</a> for
                detailed times and prices
            </p>
        </section>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\hz\API\forecastbaking\AP-app\resources\views/home.blade.php ENDPATH**/ ?>